﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;

namespace Reme
{
    class Program
    {
        public static string IV = "fr0mpwn1mp0rt5th";
        public static string PASSWORD = "Cs1sFunnuFs1sC";
        public static string SALT = "RevMePls233";
       
static void Main(string[] args)
        {
            int [] array={ 
                99,67,113,123,110,48,72,117,94,104,99,36,100,63,37,54,
                120,125,64,96,121,39,70,71,74,87,35,80,36,100,70,70,
                16,17,21,90,70,77,19,104,123,74,30,0,64,88,69,105,
                81,68,90,116,127,109,101,70,95,10,95,107,80,68,91,126
            };
            Console.WriteLine("len:"+array.Length);
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write((char)(array[i] ^ i));

            }
            Console.WriteLine("\nAES解密:");
            Console.WriteLine(AESdecode("cBsxj5NrVai/h2+9hlRsm2PPRN9K8yXY007ybh5OSc4+lukFauhGKXSqg3ePlyeA"));

             Console.ReadKey();

        }

        static string AESencode(string string_0)
        {
            AesCryptoServiceProvider aesCryptoServiceProvider = new AesCryptoServiceProvider();
            string result;
            try
            {
                ICryptoTransform arg_1E = EnAESInit(aesCryptoServiceProvider, true);
                byte[] bytes = Encoding.UTF8.GetBytes(string_0);
                result = Convert.ToBase64String(arg_1E.TransformFinalBlock(bytes, 0, bytes.Length));
            }
            finally
            {
                if (aesCryptoServiceProvider != null)
                {
                     aesCryptoServiceProvider.Dispose();
                }
            }
            return result;
        }

        private static ICryptoTransform EnAESInit(AesCryptoServiceProvider aesCryptoServiceProvider_0, bool bool_0)
        {
            aesCryptoServiceProvider_0.Mode = CipherMode.CBC;
   
            aesCryptoServiceProvider_0.Padding = PaddingMode.PKCS7;
            aesCryptoServiceProvider_0.Key = new Rfc2898DeriveBytes(Encoding.UTF8.GetBytes(PASSWORD), Encoding.UTF8.GetBytes(SALT), 65536).GetBytes(16);

            aesCryptoServiceProvider_0.IV = Encoding.UTF8.GetBytes(IV);
      
   
			return aesCryptoServiceProvider_0.CreateEncryptor();
			}


        static string AESdecode(string string_0)
        {
            AesCryptoServiceProvider aesCryptoServiceProvider = new AesCryptoServiceProvider();
            string result;
            try
            {
                
                ICryptoTransform arg_1E = DeAESInit(aesCryptoServiceProvider, true);
                
                byte[] bytes = Convert.FromBase64String(string_0);


                String r = Encoding.UTF8.GetString(arg_1E.TransformFinalBlock(bytes, 0, bytes.Length));
                result = r;


            }
            finally
            {
                if (aesCryptoServiceProvider != null)
                {
                    aesCryptoServiceProvider.Dispose();
                }
            }
            return result;
        }


        private static ICryptoTransform DeAESInit(AesCryptoServiceProvider aesCryptoServiceProvider_0, bool bool_0)
        {
            aesCryptoServiceProvider_0.Mode = CipherMode.CBC;

            aesCryptoServiceProvider_0.Padding = PaddingMode.PKCS7;
            aesCryptoServiceProvider_0.Key = new Rfc2898DeriveBytes(Encoding.UTF8.GetBytes(PASSWORD), Encoding.UTF8.GetBytes(SALT), 65536).GetBytes(16);

            aesCryptoServiceProvider_0.IV = Encoding.UTF8.GetBytes(IV);


            return aesCryptoServiceProvider_0.CreateDecryptor();
        }




    }
}



