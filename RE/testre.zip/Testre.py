from Crypto.Util.number import long_to_bytes
cipher = 'D9cS9N9iHjMLTdA8YSMRMp'
charset = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
flag = ''

for i in cipher:
  flag += chr(charset.index(i))

res = 0
for x in flag:
  res = res * 58 + ord(x)

fff = long_to_bytes(res)

print fff
